import socket
import threading
import time
import os
import datetime

# Global variables for tracking traffic and blacklisting IPs
ip_request_data = {}
blocked_ips = set()
request_threshold = 100  # Max requests allowed in a short time period
time_window = 20  # Time window in seconds to measure request speed
blacklist_duration = 60  # Duration in seconds to block an IP
request_time_threshold = 0.5  # Minimum time between requests in seconds for an IP to avoid blocking

# File paths
log_file_path = 'log.txt'
blocked_ip_file_path = 'blockedip.txt'
unblocked_ip_file_path = 'unblockedip.txt'  # New file for unblocked IPs

# Risk levels
low_risk_threshold = 50
high_risk_threshold = 100

# Load blocked IPs from file on server start
def load_blocked_ips():
    if os.path.exists(blocked_ip_file_path):
        with open(blocked_ip_file_path, 'r') as file:
            for line in file:
                ip, timestamp = line.strip().split(',')
                blocked_ips.add(ip)
    print(f"Loaded blocked IPs: {blocked_ips}")

# Save blocked IPs to file
def save_blocked_ip(ip):
    with open(blocked_ip_file_path, 'a') as file:
        timestamp = int(time.time())  # Store the current timestamp
        file.write(f"{ip},{timestamp}\n")

# Remove expired IPs from blocked list
def remove_expired_blocked_ips():
    current_time = int(time.time())
    updated_ips = set()
    
    # Rewrite the blocked IPs file excluding expired entries
    if os.path.exists(blocked_ip_file_path):
        with open(blocked_ip_file_path, 'r') as file:
            lines = file.readlines()
        
        with open(blocked_ip_file_path, 'w') as file:
            for line in lines:
                ip, timestamp = line.strip().split(',')
                if current_time - int(timestamp) < blacklist_duration:
                    file.write(line)
                    updated_ips.add(ip)
                else:
                    print(f"IP unblocked: {ip} after {blacklist_duration} seconds")
                    log_unblock(ip)  # Log unblock instantly when IP is unblocked
    
    global blocked_ips
    blocked_ips = updated_ips
    print(f"Blocked IPs after cleanup: {blocked_ips}")

# Log unblocking of an IP
def log_unblock(ip):
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_entry = f"Timestamp: {timestamp}\nUnblocked IP: {ip}\n\n"
    with open(unblocked_ip_file_path, 'a') as log_file:
        log_file.write(log_entry)
    print(log_entry.strip())  # Print unblock log entry to console

# Blocking function for IPs
def block_ip(ip):
    if ip not in blocked_ips:
        blocked_ips.add(ip)
        save_blocked_ip(ip)  # Save the blocked IP to file
        print(f"Blocked IP: {ip} for {blacklist_duration} seconds")
        print(f"Unblock time: {datetime.datetime.now() + datetime.timedelta(seconds=blacklist_duration)}")
        threading.Thread(target=unblock_ip, args=(ip,)).start()

# Unblock function for IPs
def unblock_ip(ip):
    time.sleep(blacklist_duration)
    if ip in blocked_ips:
        blocked_ips.remove(ip)
        print(f"IP unblocked: {ip} after {blacklist_duration} seconds")
        log_unblock(ip)  # Log unblock instantly when IP is unblocked
        # Remove IP from the blocked IP file (optional, but it keeps the file clean)
        with open(blocked_ip_file_path, 'r') as file:
            lines = file.readlines()
        with open(blocked_ip_file_path, 'w') as file:
            for line in lines:
                if not line.startswith(f"{ip},"):
                    file.write(line)

# Reset request count after every time window
def reset_request_count():
    global ip_request_data
    while True:
        time.sleep(time_window)
        # Clear request timestamps data after time window
        for ip in list(ip_request_data.keys()):
            ip_request_data[ip]['timestamps'] = []
        print(f"Reset request counts and timestamps.")

# Function to log detailed requests with risk levels
def log_request(ip, headers):
    request_count = ip_request_data[ip]['count']
    risk_level = 'Low'
    if request_count > high_risk_threshold:
        risk_level = 'High'
    elif request_count > low_risk_threshold:
        risk_level = 'Medium'

    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    with open(log_file_path, 'a') as log_file:
        log_entry = f"Timestamp: {timestamp}\nRisk Level: {risk_level}\nIP: {ip}\n{headers}\n\n"
        log_file.write(log_entry)
        print(f"Logged: {log_entry.strip()}")

# Function to handle requests and detect potential DDoS
def handle_connection(client_socket, client_address):
    # Read request data
    request_data = client_socket.recv(4096).decode()
    headers = request_data.split('\r\n')

    # Extract the true source IP from X-Forwarded-For if available
    source_ip = client_address[0]
    for header in headers:
        if header.lower().startswith('x-forwarded-for:'):
            source_ip = header.split(':', 1)[1].strip()
            break

    # Check if the IP is blocked
    remove_expired_blocked_ips()  # Clean up old blocked IPs
    if source_ip in blocked_ips:
        print(f"Blocked IP: {source_ip} is trying to access the server. Access denied.")
        response = "HTTP/1.1 404 Not Found\n\n404 Error: IP Blocked"
        client_socket.sendall(response.encode())
        client_socket.close()
        return

    # Track request count and timestamps for the IP
    current_time = time.time()
    if source_ip not in ip_request_data:
        ip_request_data[source_ip] = {'count': 0, 'timestamps': []}
    
    ip_request_data[source_ip]['count'] += 1
    ip_request_data[source_ip]['timestamps'].append(current_time)

    # Check for fast requests (DDoS attack detection)
    timestamps = ip_request_data[source_ip]['timestamps']
    if len(timestamps) > 1:
        time_diff = timestamps[-1] - timestamps[-2]
        if time_diff < request_time_threshold:
            # Check if the user is refreshing the page frequently
            if len(timestamps) > 10 and all(time_diff < request_time_threshold for time_diff in [timestamps[i] - timestamps[i-1] for i in range(1, 6)]):
                # Allow frequent refreshes from legitimate users
                pass
            else:
                block_ip(source_ip)
                response = "HTTP/1.1 404 Not Found\n\n404 Error: IP Blocked"
                client_socket.sendall(response.encode())
                client_socket.close()
                return

    # Check if the IP exceeds the request threshold
    if ip_request_data[source_ip]['count'] > request_threshold:
        block_ip(source_ip)
        response = "HTTP/1.1 404 Not Found\n\n404 Error: IP Blocked"
        client_socket.sendall(response.encode())
        client_socket.close()
        return

    # Simulate legitimate traffic handling (responding to valid requests)
    try:
        # Serve index.html for GET requests
        if request_data.startswith('GET / HTTP/1.1'):
            with open('index.html', 'r') as file:
                response_body = file.read()
            response = f"HTTP/1.1 200 OK\nContent-Type: text/html\n\n{response_body}"
        else:
            response = "HTTP/1.1 404 Not Found\n\nFile Not Found"
        
        client_socket.sendall(response.encode())
        log_request(source_ip, '\n'.join(headers))  # Log the request details
    except Exception as e:
        print(f"Error handling request from {source_ip}: {e}")
    
    client_socket.close()

# Function to start the server and listen for connections
def start_server(host, port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Server listening on {host}:{port}")

    # Load existing blocked IPs
    load_blocked_ips()

    # Start thread to reset IP request counts every time window
    threading.Thread(target=reset_request_count, daemon=True).start()

    while True:
        client_socket, client_address = server_socket.accept()
        threading.Thread(target=handle_connection, args=(client_socket, client_address)).start()

if __name__ == "__main__":
    start_server("0.0.0.0", 7565)