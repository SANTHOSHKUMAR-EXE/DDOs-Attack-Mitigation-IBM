<?php
$blocked_ips = file('blockedip.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
echo json_encode(['blocked_ips' => $blocked_ips]);
?>
