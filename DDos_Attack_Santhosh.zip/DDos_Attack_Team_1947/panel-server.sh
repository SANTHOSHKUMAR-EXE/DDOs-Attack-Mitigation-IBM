#!/bin/bash
# Start PHP server in the current directory
php -S localhost:4444
