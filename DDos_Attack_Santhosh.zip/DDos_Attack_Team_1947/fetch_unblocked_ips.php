<?php
$unblocked_ips = file('unblockedip.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
echo json_encode(['unblocked_ips' => $unblocked_ips]);
?>
